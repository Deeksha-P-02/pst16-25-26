public class Main {
    public static void main(String[] args) {
        String str="kumar";
        char[]arr = str.toCharArray();
        for (int i= arr.lenght- 1;i>=0;i--){
            System.out.println(arr[i]);
        }

        
    }
}